﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using SEDOL_CHECKER;
using SEDOL_CHECKER.SEDOL_INTERFACES;
using Assert = NUnit.Framework.Assert;

namespace SedolTestValidator
{
   
     [TestFixture]
    public class SedolTestValidator
    {

        [TestCase(null)]
        [TestCase("")]
        [TestCase("123456789")]
        [TestCase("12")]
        public void SedolsWithInvalidLength(string sedol)
        {
            var actual = new SedolValidator().ValidateSedol(sedol);
            var expected = new ValidationResult(sedol, false, false, Common.INVALID_INPUT_STRING);
            AssertValidationResult(expected, actual);
        }

        [TestCase("1234567")]
        public void SedolsWithIncorrectChecksum(string sedol)
        {
            var actual = new SedolValidator().ValidateSedol(sedol);
            var expected = new ValidationResult(sedol, false, false, Common.INVALID_CHECKSUM);
            AssertValidationResult(expected, actual);
        }

        [TestCase("0709954")]
        [TestCase("B0YBKJ7")]
        public void ValidSedols(string sedol)
        {
            var actual = new SedolValidator().ValidateSedol(sedol);
            var expected = new ValidationResult(sedol, true, false, null);
            AssertValidationResult(expected, actual);
        }

        [TestCase("9123451")]
        [TestCase("9ABCDE8")]
        public void UserDefinedSedolsWithIncorrectChecksum(string sedol)
        {
            var actual = new SedolValidator().ValidateSedol(sedol);
            var expected = new ValidationResult(sedol, false, true, Common.INVALID_CHECKSUM);
            AssertValidationResult(expected, actual);
        }

        [TestCase("9123_51")]
        [TestCase("VA.CDE8")]
        public void SedolsContainingInvalidCharacters(string sedol)
        {
            var actual = new SedolValidator().ValidateSedol(sedol);
            var expected = new ValidationResult(sedol, false, false, Common.INVALID_CHARACTERS);
            AssertValidationResult(expected, actual);
        }

        [TestCase("9123458")]
        [TestCase("9ABCDE1")]
        public void UserDefinedSedolsWithCorrectChecksum(string sedol)
        {
            var actual = new SedolValidator().ValidateSedol(sedol);
            var expected = new ValidationResult(sedol, true, true, null);
            AssertValidationResult(expected, actual);
        }

        private static void AssertValidationResult(IValidationResult expected, IValidationResult actual)
        {
            Assert.AreEqual(expected.InputString, actual.InputString, "Input String Failed");
            Assert.AreEqual(expected.IsValidSedol, actual.IsValidSedol, "Is Valid Failed");
            Assert.AreEqual(expected.IsUserDefined, actual.IsUserDefined, "Is User Defined Failed");
            Assert.AreEqual(expected.ValidationDetails, actual.ValidationDetails, "Validation Details Failed");
        }
    }
}
