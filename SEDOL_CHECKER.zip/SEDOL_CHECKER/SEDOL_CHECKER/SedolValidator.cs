﻿using System;
using System.Collections.Generic;
using System.Text;
using SEDOL_CHECKER.SEDOL_INTERFACES;

namespace SEDOL_CHECKER
{
    public class SedolValidator : ISedolValidator
    {
        public IValidationResult ValidateSedol(string input)
        {
            var sedol = new ValidateSedol(input);

            var result = new ValidationResult
            {
                InputString = input,
                IsUserDefined = false,
                IsValidSedol = false,
                ValidationDetails = null
            };

            if (!sedol.IsValidLength)
            {
                result.ValidationDetails = Common.INVALID_INPUT_STRING;
                return result;
            }
            if (!sedol.IsAlphaNumeric)
            {
                result.ValidationDetails = Common.INVALID_CHARACTERS;
                return result;
            }
            if (sedol.IsUserDefined)
            {
                result.IsUserDefined = true;
                if (sedol.HasValidCheckDigit)
                {
                    result.IsValidSedol = true;
                    return result;
                }
                result.ValidationDetails = Common.INVALID_CHECKSUM;
                return result;
            }

            if (sedol.HasValidCheckDigit)
                result.IsValidSedol = true;
            else
                result.ValidationDetails = Common.INVALID_CHECKSUM;

            return result;
        }
    }
}
