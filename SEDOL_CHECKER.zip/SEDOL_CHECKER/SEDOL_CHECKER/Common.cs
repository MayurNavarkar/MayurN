﻿using System;

namespace SEDOL_CHECKER
{
    public class Common
    {
        public const string INVALID_INPUT_STRING= "Input string was not 7-characters long";
        public const string INVALID_CHARACTERS = "SEDOL contains invalid characters";
        public const string INVALID_CHECKSUM = "Checksum digit does not agree with the rest of the input";
    }
}
