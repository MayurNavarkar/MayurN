﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEDOL_CHECKER.SEDOL_INTERFACES
{
   
    public interface ISedolValidator
    {
        /// <summary>
        /// Validates the SEDOL.
        /// </summary>
        /// <param name="input">The input.</param>
        /// <returns>Instance of validation result.</returns>
        IValidationResult ValidateSedol(string input);
    }
}
